class MyThread1 extends Thread {
    public void run() {
        try {
            while (true) {
                System.out.println("MyThread1 is running");
                Thread.sleep(500); // 1초 대기
            }
        } catch (InterruptedException ie) {
            System.out.println("MyThread1 interrupted");
        }
    }
}


