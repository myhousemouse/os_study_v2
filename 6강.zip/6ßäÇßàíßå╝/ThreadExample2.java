public class ThreadExample2 {
    public static void main(String[] args) {
        Thread thread = new Thread(new MyThread2()); // Thread 호출 -> MyThread2 객체 생성
        thread.start(); // MyThread1 실행과 같음
    }
}
